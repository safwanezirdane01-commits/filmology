import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/Providers";
import Navbar from "@/components/Navbar";
import AdBlockDetector from "@/components/AdBlockDetector";
import PWAInstallPrompt from "@/components/PWAInstallPrompt";
import AnalyticsTracker from "@/components/AnalyticsTracker";

const inter = Inter({ subsets: ["latin"] });

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#020617",
};

export const metadata: Metadata = {
  metadataBase: new URL("https://filmologyx.vercel.app"),
  title: "FilmologyX | Watch Movies Free",
  description: "The ultimate platform for streaming the best movies. Watch high-quality animation, sci-fi, horror, and action films for free on FilmologyX.",
  keywords: ["streaming", "movies", "watch free", "filmologyx", "cinema"],
  icons: {
    icon: "/icon.png",
    shortcut: "/icon.png",
    apple: "/apple-touch-icon.png",
  },
  openGraph: {
    title: "FilmologyX | Watch Movies & TV Series Free in HD",
    description: "Stream 10,000+ movies & full TV series in 1080p HD completely free on FilmologyX.",
    url: "https://filmologyx.vercel.app",
    siteName: "FilmologyX",
    images: [
      {
        url: "/banner.png",
        width: 1280,
        height: 720,
        alt: "FilmologyX - Free Movie & TV Series Streaming",
      },
    ],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "FilmologyX | Watch Movies & TV Series Free in HD",
    description: "Stream 10,000+ movies & full TV series in 1080p HD completely free on FilmologyX.",
    images: ["/banner.png"],
  },
  verification: {
    google: "BjT37pboaQsm68KPq3wiRCm1gq7EmuX7c5IPaxVASaE",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} bg-slate-950 text-slate-100 min-h-screen flex flex-col selection:bg-rose-500/30 selection:text-rose-200`}>
        <Providers>
          <AdBlockDetector />
          <Navbar />
          <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-3 sm:py-6">
            {children}
          </main>
          <PWAInstallPrompt />
          <AnalyticsTracker />
        </Providers>
      </body>
    </html>
  );
}
