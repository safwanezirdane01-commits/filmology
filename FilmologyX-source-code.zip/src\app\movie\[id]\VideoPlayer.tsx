"use client";

import { useState, useRef, useEffect, useMemo, useCallback } from "react";
import { Play, Server, Film, ShieldCheck, Tv, ChevronLeft, ChevronRight, Download, Clock, RotateCcw, RefreshCw, Maximize2, Minimize2, PictureInPicture2, FastForward, X, Keyboard } from "lucide-react";
import { isRealSeries, getSeriesMetadata, getEpisodesForSeason } from "@/lib/series";
import SeriesEpisodeNavigator from "@/components/SeriesEpisodeNavigator";
import { saveWatchProgress, getWatchProgress, clearWatchItem, formatTime, WatchItem } from "@/lib/watchProgress";
import NativeArabicPlayer from "@/components/NativeArabicPlayer";

export default function VideoPlayer({ 
  movieId,
  movieVideoUrl, 
  thumbnailUrl,
  genre,
  title = "Movie",
  adDirectLink,
  requiredClicks = 2,
  adsEnabled = true,
}: { 
  movieId: string;
  movieVideoUrl: string | null; 
  thumbnailUrl: string | null;
  genre?: string;
  title?: string;
  adDirectLink?: string;
  requiredClicks?: number;
  adsEnabled?: boolean;
}) {
  const [clickCount, setClickCount] = useState(0);
  const [selectedServer, setSelectedServer] = useState<number>(1);
  const [serverNotice, setServerNotice] = useState<string | null>(null);
  const [season, setSeason] = useState<number>(1);
  const [episode, setEpisode] = useState<number>(1);
  const DEFAULT_AD_LINK = "https://consciousdunkvastly.com/vkcab8pm?key=2d7f9ab1644671035abd720ada6bab69";
  const activeAdLink = (adDirectLink && adDirectLink.startsWith("http")) ? adDirectLink : DEFAULT_AD_LINK;
  const effectiveClicks = (typeof requiredClicks === "number" && requiredClicks > 0) ? requiredClicks : 3;
  const targetClicks = Math.max(1, effectiveClicks);
  const videoRef = useRef<HTMLVideoElement>(null);


  // Arabic subtitle state & IMDb ID resolution
  const [arabicSubTracks, setArabicSubTracks] = useState<Array<{ id: string; label: string; url: string }>>([]);
  const [activeArabicSubUrl, setActiveArabicSubUrl] = useState<string | null>(null);
  const [loadingSubs, setLoadingSubs] = useState<boolean>(false);
  const [resolvedImdbId, setResolvedImdbId] = useState<string | null>(null);

  // Watch progress tracking state
  const [savedProgress, setSavedProgress] = useState<WatchItem | null>(null);
  const [showResumeBanner, setShowResumeBanner] = useState<boolean>(true);
  const [isServerLoaded, setIsServerLoaded] = useState<boolean>(false);

  // Direct stream (ad-free native player) state
  const [directStream, setDirectStream] = useState<{ url: string; type: string } | null>(null);
  const [directLoading, setDirectLoading] = useState<boolean>(false);
  const [directFailed, setDirectFailed] = useState<boolean>(false);

  // Cinema Theater Mode & PiP states
  const [isTheaterMode, setIsTheaterMode] = useState<boolean>(false);
  const [isFloatingPiP, setIsFloatingPiP] = useState<boolean>(false);

  // Auto-play Next Episode (Binge-Watching Mode)
  const [autoNextEnabled, setAutoNextEnabled] = useState<boolean>(true);
  const [showNextCountdown, setShowNextCountdown] = useState<boolean>(false);
  const [countdownRemaining, setCountdownRemaining] = useState<number>(5);

  // Cinema Keyboard Shortcuts & Toast state
  const [showHotkeysModal, setShowHotkeysModal] = useState<boolean>(false);
  const [hotkeyToast, setHotkeyToast] = useState<string | null>(null);

  // Countdown timer for next episode
  useEffect(() => {
    let timer: any;
    if (showNextCountdown && countdownRemaining > 0) {
      timer = setTimeout(() => {
        setCountdownRemaining((prev) => prev - 1);
      }, 1000);
    } else if (showNextCountdown && countdownRemaining <= 0) {
      setShowNextCountdown(false);
      setEpisode((prev) => prev + 1);
    }
    return () => clearTimeout(timer);
  }, [showNextCountdown, countdownRemaining]);

  const handleTogglePiP = async () => {
    if (parsedSources?.isDirectVideo && videoRef.current) {
      try {
        if (document.pictureInPictureElement) {
          await document.exitPictureInPicture();
        } else {
          await videoRef.current.requestPictureInPicture();
        }
      } catch {
        setIsFloatingPiP((prev) => !prev);
      }
    } else {
      setIsFloatingPiP((prev) => !prev);
    }
  };

  // Check if title is a TV Series (strict - movies are NEVER a series)
  const isSeries = useMemo(() => {
    return isRealSeries(movieVideoUrl, genre);
  }, [genre, movieVideoUrl]);

  const seriesMeta = useMemo(() => {
    return isSeries ? getSeriesMetadata(movieVideoUrl, genre) : null;
  }, [isSeries, movieVideoUrl, genre]);

  // Live season/episode data fetched from TMDB — always accurate for every show
  const [liveMeta, setLiveMeta] = useState<{ totalSeasons: number; seasons: Record<number, number> } | null>(null);

  useEffect(() => {
    if (!isSeries || !movieVideoUrl) return;
    const tmdbId = movieVideoUrl.replace(/^tv[:-]/i, "").trim();
    if (!/^\d+$/.test(tmdbId)) return;

    fetch(`/api/tv-info?id=${tmdbId}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.totalSeasons && data.seasons) {
          setLiveMeta({ totalSeasons: data.totalSeasons, seasons: data.seasons });
        }
      })
      .catch(() => {});
  }, [isSeries, movieVideoUrl]);

  // Effective meta: prefer live TMDB data, fall back to static
  const effectiveMeta = liveMeta || seriesMeta;

  const availableEpisodesCount = useMemo(() => {
    if (!isSeries) return 0;
    if (effectiveMeta) return effectiveMeta.seasons[season] || 10;
    return getEpisodesForSeason(movieVideoUrl, season, genre);
  }, [isSeries, effectiveMeta, movieVideoUrl, season, genre]);

  // Load saved watch progress for current title/season/episode
  useEffect(() => {
    if (!movieId) return;
    const progress = getWatchProgress(movieId, season, episode);
    setSavedProgress(progress);
    setShowResumeBanner(!!progress);
  }, [movieId, season, episode]);

  // 🎯 Direct ad-free stream: try /api/stream first, fall back to iframes if it fails
  useEffect(() => {
    if (!movieVideoUrl) {
      setDirectLoading(false);
      setDirectFailed(true);
      return;
    }

    setDirectLoading(true);
    setDirectStream(null);
    setDirectFailed(false);

    // Determine type and clean id
    const tvPrefix = /^tv[-:]/i.test(movieVideoUrl) || /^tv%3A/i.test(movieVideoUrl);
    const mediaType = tvPrefix || isSeries ? "tv" : "movie";
    const cleanId = movieVideoUrl.replace(/^tv[-:%3A]+/i, "").trim();

    const params = new URLSearchParams({
      id: cleanId,
      type: mediaType,
      season: String(season),
      episode: String(episode),
    });

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    fetch(`/api/stream?${params}`, { signal: controller.signal })
      .then((r) => r.json())
      .then((data) => {
        if (data.success && data.url) {
          setDirectStream({ url: data.url, type: data.type || "application/x-mpegURL" });
        } else {
          setDirectFailed(true);
        }
      })
      .catch(() => setDirectFailed(true))
      .finally(() => {
        clearTimeout(timeout);
        setDirectLoading(false);
      });

    return () => {
      controller.abort();
      clearTimeout(timeout);
    };
  }, [movieVideoUrl, isSeries, season, episode]);


  // 🛡️ Option C: Client-Side Pop-under Defuser & Window Shield
  useEffect(() => {
    if (typeof window === "undefined") return;

    // Intercept and neutralize any rogue window.open calls from escaping scripts
    const originalOpen = window.open;
    window.open = function (url?: string | URL, target?: string, features?: string) {
      const urlStr = typeof url === "string" ? url : url?.toString() || "";
      // Only permit our authorized monetization ad link
      if (urlStr && activeAdLink && (urlStr === activeAdLink || urlStr.startsWith(activeAdLink.split("?")[0]))) {
        return originalOpen.call(window, url, target, features);
      }
      console.warn("🛡️ FilmologyX Defuser: Blocked unauthorized popup to:", urlStr);
      return null;
    };

    return () => {
      window.open = originalOpen;
    };
  }, [activeAdLink]);



  // Listen for player postMessage events (e.g. VidLink or HTML5 video) for progress & auto load status
  useEffect(() => {
    const handleMsg = (e: MessageEvent) => {
      try {
        if (e.data && typeof e.data === "object") {
          setIsServerLoaded(true);
          const { type, data, time, duration } = e.data;
          let curr = 0;
          let dur = 0;
          if (type === "MEDIA_DATA" && data) {
            curr = data.currentTime || data.time || 0;
            dur = data.duration || 0;
          } else if (typeof time === "number") {
            curr = time;
            dur = duration || 0;
          }
          if (curr > 5 && movieId) {
            saveWatchProgress({
              id: movieId,
              title: title || "Movie",
              thumbnailUrl,
              currentTime: Math.floor(curr),
              duration: Math.floor(dur) || 7200,
              genre,
              season: isSeries ? season : undefined,
              episode: isSeries ? episode : undefined,
            });
            const updated = getWatchProgress(movieId, season, episode);
            if (updated) setSavedProgress(updated);
          }
        }
      } catch {}
    };

    window.addEventListener("message", handleMsg);
    return () => window.removeEventListener("message", handleMsg);
  }, [movieId, movieVideoUrl, title, thumbnailUrl, genre, isSeries, season, episode]);

  // Periodic watch progress saver while user stays on player page
  useEffect(() => {
    if (!movieId) return;
    const interval = setInterval(() => {
      const existing = getWatchProgress(movieId, season, episode);
      const newTime = (existing?.currentTime || 0) + 15;
      saveWatchProgress({
        id: movieId,
        title: title || "Movie",
        thumbnailUrl,
        currentTime: newTime,
        duration: existing?.duration || 7200,
        genre,
        season: isSeries ? season : undefined,
        episode: isSeries ? episode : undefined,
      });
      const p = getWatchProgress(movieId, season, episode);
      if (p) setSavedProgress(p);
    }, 15000);

    return () => clearInterval(interval);
  }, [movieId, title, thumbnailUrl, genre, isSeries, season, episode]);

  // Fetch verified Arabic subtitles from /api/subtitles & resolve IMDb ID
  useEffect(() => {
    if (!movieVideoUrl) return;
    setLoadingSubs(true);
    fetch(`/api/subtitles?id=${encodeURIComponent(movieVideoUrl)}&type=${isSeries ? "series" : "movie"}&season=${season}&episode=${episode}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          if (data.imdbId) {
            setResolvedImdbId(data.imdbId);
          }
          if (data.tracks && data.tracks.length > 0) {
            setArabicSubTracks(data.tracks);
            const origin = typeof window !== "undefined" ? window.location.origin : "";
            const proxied = `${origin}/api/subtitles/vtt?url=${encodeURIComponent(data.defaultArabicUrl)}`;
            setActiveArabicSubUrl(proxied);
          } else {
            setArabicSubTracks([]);
            setActiveArabicSubUrl(null);
          }
        }
      })
      .catch((err) => console.warn("Failed to load Arabic subtitles:", err))
      .finally(() => setLoadingSubs(false));
  }, [movieVideoUrl, isSeries, season, episode]);

  // Read URL query params on mount for direct episode deep-linking (e.g. ?s=1&e=2)
  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const sParam = params.get("season") || params.get("s");
      const eParam = params.get("episode") || params.get("e");
      if (sParam) {
        const sNum = parseInt(sParam, 10);
        if (!isNaN(sNum) && sNum >= 1) setSeason(sNum);
      }
      if (eParam) {
        const eNum = parseInt(eParam, 10);
        if (!isNaN(eNum) && eNum >= 1) setEpisode(eNum);
      }
    }
  }, []);

  // Normalize and parse the video URL or ID
  const parsedSources = useMemo(() => {
    if (!movieVideoUrl) return null;

    let trimmed = movieVideoUrl.trim();
    if (trimmed.startsWith("tv:")) {
      trimmed = trimmed.replace("tv:", "");
    }

    // Check whether trimmed is an IMDb ID (e.g. tt0816692) or TMDb ID (e.g. 157336 or 1399)
    const isDirectImdb = /^tt\d+$/i.test(trimmed);
    const isDirectTmdb = /^\d+$/.test(trimmed);

    // Keep TMDb ID clean (numeric) and IMDb ID clean (starts with tt)
    const effectiveTmdb = isDirectTmdb ? trimmed : "";
    const effectiveImdb = isDirectImdb ? trimmed : (resolvedImdbId || "");
    const effectiveId = effectiveTmdb || effectiveImdb || trimmed;

    // Check if it's a direct video link (.mp4, .webm, .ogg, .m3u8, etc.)
    const isDirectVideo = /\.(mp4|webm|ogg|m4v|m3u8)($|\?)/i.test(trimmed) || 
      trimmed.includes("gtv-videos-bucket") || 
      trimmed.includes("commondatastorage.googleapis.com");

    // Check if YouTube
    const ytMatch = trimmed.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i);
    const youtubeEmbed = ytMatch ? `https://www.youtube-nocookie.com/embed/${ytMatch[1]}?autoplay=1` : null;

    let server1 = "";
    let server2 = "";
    let server3 = "";
    let server4 = "";
    let server5 = "";

    const tmdbParam = effectiveTmdb || trimmed;
    const imdbParam = effectiveImdb || trimmed;

    if (isSeries && (isDirectImdb || isDirectTmdb || resolvedImdbId)) {
      server1 = `https://vidlink.pro/tv/${tmdbParam}/${season}/${episode}?primaryColor=e11d48&secondaryColor=a855f7&autoplay=true`;
      server2 = `https://player.videasy.net/tv/${tmdbParam}/${season}/${episode}?color=e11d48`;
      server3 = `https://vidsrc.su/embed/tv/${tmdbParam}/${season}/${episode}`;
      server4 = `https://autoembed.cc/tv/tmdb/${tmdbParam}-${season}-${episode}`;
      server5 = `https://vidfast.pro/tv/${tmdbParam}/${season}/${episode}?autoPlay=true`;
    } else if (isDirectImdb || isDirectTmdb || resolvedImdbId) {
      server1 = `https://vidlink.pro/movie/${tmdbParam}?primaryColor=e11d48&secondaryColor=a855f7&autoplay=true`;
      server2 = `https://player.videasy.net/movie/${tmdbParam}?color=e11d48`;
      server3 = `https://vidsrc.su/embed/movie/${tmdbParam}`;
      server4 = `https://autoembed.cc/movie/tmdb/${tmdbParam}`;
      server5 = `https://vidfast.pro/movie/${tmdbParam}?autoPlay=true`;
    } else if (youtubeEmbed) {
      server1 = youtubeEmbed;
      server2 = youtubeEmbed;
      server3 = youtubeEmbed;
      server4 = youtubeEmbed;
      server5 = youtubeEmbed;
    } else if (isDirectVideo) {
      server1 = trimmed;
      server2 = trimmed;
      server3 = trimmed;
      server4 = trimmed;
      server5 = trimmed;
    } else {
      server1 = trimmed;
      server2 = trimmed;
      server3 = trimmed;
      server4 = trimmed;
      server5 = trimmed;
    }

    return {
      isImdbOrTmdb: isDirectImdb || isDirectTmdb || !!resolvedImdbId || (!isDirectVideo && !youtubeEmbed),
      isDirectVideo,
      server1,
      server2,
      server3,
      server4,
      server5,
      currentUrl: selectedServer === 1 ? server1 : selectedServer === 2 ? server2 : selectedServer === 3 ? server3 : selectedServer === 4 ? server4 : server5
    };
  }, [movieVideoUrl, resolvedImdbId, selectedServer, isSeries, season, episode]);



  const handleFakeClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    // Immediately trigger the ad tab upon direct user click
    try {
      window.open(activeAdLink, "_blank");
    } catch (err) {
      console.error("Popup launch error:", err);
    }

    setClickCount((prev) => prev + 1);
  };

  // Auto-play when direct video becomes unblocked
  useEffect(() => {
    if (clickCount >= targetClicks && videoRef.current && parsedSources?.isDirectVideo) {
      videoRef.current.play().catch(e => console.log("Autoplay blocked:", e));
    }
  }, [clickCount, targetClicks, parsedSources]);

  if (!movieVideoUrl || !parsedSources) {
    return (
      <div className="w-full aspect-video rounded-2xl sm:rounded-3xl flex flex-col items-center justify-center bg-slate-950 text-purple-300/60 p-6 text-center border border-purple-500/20">
        <Film className="w-12 h-12 mb-3 text-purple-600/40 animate-pulse" />
        <h3 className="text-lg font-bold text-white mb-1">No Video Available</h3>
        <p className="text-xs max-w-sm">Add a video link or IMDb/TMDb ID in the Admin panel to start streaming.</p>
      </div>
    );
  }

  const needsPopups = (adsEnabled ?? true) && clickCount < targetClicks;

  const serverList = useMemo(() => [
    { id: 1, label: "VidLink (Fast HD)", short: "VidLink" },
    { id: 2, label: "Videasy (Clean)", short: "Videasy" },
    { id: 3, label: "VidSrc SU (Backup)", short: "VidSrc SU" },
    { id: 4, label: "AutoEmbed (Stream 4)", short: "AutoEmbed" },
    { id: 5, label: "VidFast (Stream 5)", short: "VidFast" },
  ], []);

  const handleNextServer = useCallback(() => {
    setSelectedServer((prev) => {
      const next = prev >= 5 ? 1 : prev + 1;
      const targetServer = serverList.find((s) => s.id === next);
      const name = targetServer ? targetServer.label : `Server ${next}`;
      setServerNotice(`Switched to ${name}`);
      setTimeout(() => setServerNotice(null), 3000);
      return next;
    });
  }, [serverList]);

  // Pro Cinema Keyboard Shortcuts Handler
  useEffect(() => {
    let toastTimer: any;
    const triggerToast = (msg: string) => {
      setHotkeyToast(msg);
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => setHotkeyToast(null), 1800);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is currently typing in an input, textarea, or select
      const target = e.target as HTMLElement;
      if (
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.tagName === "SELECT" ||
          target.isContentEditable)
      ) {
        return;
      }

      // ESC: Exit Theater mode, close hotkeys modal, close PiP
      if (e.key === "Escape") {
        if (showHotkeysModal) {
          setShowHotkeysModal(false);
          return;
        }
        if (isTheaterMode) {
          setIsTheaterMode(false);
          triggerToast("Theater Mode: OFF");
          return;
        }
        if (isFloatingPiP) {
          setIsFloatingPiP(false);
          return;
        }
      }

      // '?' or Shift + '/': Toggle Hotkeys Help Modal
      if (e.key === "?" || (e.shiftKey && e.key === "/")) {
        e.preventDefault();
        setShowHotkeysModal((prev) => !prev);
        return;
      }

      // 't' or 'T': Toggle Cinema Theater Mode
      if (e.key === "t" || e.key === "T") {
        e.preventDefault();
        setIsTheaterMode((prev) => {
          triggerToast(!prev ? "🎬 Cinema Theater: ON" : "Cinema Theater: OFF");
          return !prev;
        });
        return;
      }

      // 'f' or 'F': Toggle Browser Fullscreen on Player
      if (e.key === "f" || e.key === "F") {
        e.preventDefault();
        const screenEl = document.getElementById("video-player-screen");
        if (!document.fullscreenElement && screenEl) {
          screenEl.requestFullscreen().catch(() => {});
          triggerToast("⛶ Fullscreen");
        } else if (document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        }
        return;
      }

      // 'p' or 'P': Toggle Mini-Player PiP
      if (e.key === "p" || e.key === "P") {
        e.preventDefault();
        handleTogglePiP();
        triggerToast("📺 Mini-Player PiP");
        return;
      }

      // 'n' or 'N': Advance to Next Episode (for TV series)
      if ((e.key === "n" || e.key === "N") && isSeries) {
        e.preventDefault();
        setEpisode((prev) => {
          triggerToast(`⏭️ Episode ${prev + 1}`);
          return prev + 1;
        });
        return;
      }

      // Native / Direct Video Shortcuts
      if (videoRef.current) {
        if (e.code === "Space" || e.key === "k" || e.key === "K") {
          e.preventDefault();
          if (videoRef.current.paused) {
            videoRef.current.play().catch(() => {});
            triggerToast("▶ Play");
          } else {
            videoRef.current.pause();
            triggerToast("⏸ Pause");
          }
        } else if (e.key === "ArrowLeft") {
          e.preventDefault();
          videoRef.current.currentTime = Math.max(0, videoRef.current.currentTime - 10);
          triggerToast("⏪ -10s");
        } else if (e.key === "ArrowRight") {
          e.preventDefault();
          videoRef.current.currentTime = Math.min(
            videoRef.current.duration || 99999,
            videoRef.current.currentTime + 10
          );
          triggerToast("⏩ +10s");
        } else if (e.key === "m" || e.key === "M") {
          e.preventDefault();
          videoRef.current.muted = !videoRef.current.muted;
          triggerToast(videoRef.current.muted ? "🔇 Muted" : "🔊 Unmuted");
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      clearTimeout(toastTimer);
    };
  }, [isTheaterMode, showHotkeysModal, isFloatingPiP, isSeries, episode, handleTogglePiP]);

  return (
    <div className="flex flex-col gap-3 w-full">
      {/* Resume Watching Progress Banner */}
      {showResumeBanner && savedProgress && savedProgress.currentTime > 10 && (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-gradient-to-r from-rose-950/90 via-purple-950/90 to-slate-900/95 border border-rose-500/40 p-3.5 sm:px-5 sm:py-3 rounded-2xl sm:backdrop-blur-md shadow-xl transition-all">
          <div className="flex items-center space-x-3 text-slate-100">
            <div className="p-2 bg-rose-500/20 text-rose-400 rounded-xl border border-rose-500/30 shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-white text-xs sm:text-sm">Continue Watching</span>
                <span className="bg-rose-500/25 text-rose-300 font-extrabold px-2 py-0.5 rounded-md text-[10px]">
                  {savedProgress.progressPercent}% Completed
                </span>
              </div>
              <p className="text-slate-300 text-xs mt-0.5">
                You stopped at <strong className="text-rose-400 font-bold">{formatTime(savedProgress.currentTime)}</strong>. Click to jump back to where you left off.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 w-full sm:w-auto shrink-0">
            <button
              type="button"
              onClick={() => {
                setShowResumeBanner(false);
              }}
              className="flex-1 sm:flex-none inline-flex items-center justify-center space-x-1.5 bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-lg transition-transform hover:scale-105 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Resume at {formatTime(savedProgress.currentTime)}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                clearWatchItem(movieId, season, episode);
                setSavedProgress(null);
                setShowResumeBanner(false);
              }}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-purple-500/20 cursor-pointer"
              title="Clear watch progress and start from 0:00"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* 16:9 Video Player Screen */}
      <div id="video-player-screen" className="relative aspect-video w-full bg-black rounded-2xl sm:rounded-3xl overflow-hidden border border-purple-500/30 shadow-[0_0_50px_rgba(139,92,246,0.3)] gpu-layer">
        {/* Netflix-style Binge Mode Next Episode Countdown Overlay */}
        {showNextCountdown && isSeries && (
          <div className="absolute inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-6 text-center backdrop-blur-sm">
            <div className="bg-slate-900/95 border border-purple-500/40 p-6 rounded-2xl max-w-xs sm:max-w-sm w-full shadow-2xl flex flex-col items-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 mb-1">
                Up Next in Binge Mode
              </span>
              <h4 className="text-base sm:text-lg font-bold text-white mb-2">
                Season {season} : Episode {episode + 1}
              </h4>
              <div className="w-14 h-14 rounded-full border-4 border-rose-500/20 border-t-rose-500 flex items-center justify-center my-2 animate-spin">
                <span className="text-lg font-extrabold text-white animate-none">{countdownRemaining}</span>
              </div>
              <p className="text-xs text-slate-400 mb-4">Starting next episode automatically...</p>
              <div className="flex items-center space-x-2.5 w-full">
                <button
                  type="button"
                  onClick={() => {
                    setShowNextCountdown(false);
                    setEpisode((prev) => prev + 1);
                  }}
                  className="flex-1 bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white text-xs font-bold py-2 rounded-xl shadow cursor-pointer"
                >
                  Play Now
                </button>
                <button
                  type="button"
                  onClick={() => setShowNextCountdown(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Desktop Overlay Server Bar (visible on sm+) */}
        {parsedSources.isImdbOrTmdb && (
          <div className="hidden sm:flex absolute top-3 left-3 right-3 z-40 items-center justify-between bg-slate-950/85 sm:backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-purple-500/20 text-xs">
            <div className="flex items-center space-x-1.5 text-rose-300 font-medium">
              <Server className="w-3.5 h-3.5 text-rose-400" />
              <span>Server:</span>
            </div>

            <div className="flex items-center space-x-1.5 flex-wrap">
              {serverList.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSelectedServer(s.id)}
                  className={`px-2.5 py-1 rounded-lg font-semibold transition-all text-xs cursor-pointer ${
                    selectedServer === s.id
                      ? "bg-gradient-to-r from-rose-600 to-purple-600 text-white shadow-sm"
                      : "bg-slate-800/80 text-purple-200 hover:bg-slate-700"
                  }`}
                >
                  {s.label}
                </button>
              ))}

              <button
                type="button"
                onClick={() => handleNextServer()}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold border border-purple-500/20 flex items-center space-x-1 cursor-pointer transition-colors"
                title="Stream buffering or not working? Click to try next server"
              >
                <RefreshCw className="w-3 h-3 text-rose-400" />
                <span>Next ↻</span>
              </button>
            </div>
          </div>
        )}

        {/* Desktop Overlay TV Series Selector (visible on sm+) */}
        {isSeries && (
          <div className="hidden sm:flex absolute top-13 left-3 right-3 z-40 flex-wrap items-center justify-between gap-2 bg-slate-950/90 sm:backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-purple-500/20 text-xs">
            <div className="flex items-center space-x-3">
              <span className="font-bold text-rose-400 uppercase tracking-wider flex items-center space-x-1">
                <Tv className="w-3.5 h-3.5" />
                <span>Series</span>
              </span>
              <div className="flex items-center space-x-1.5">
                <span className="text-slate-400">Season:</span>
                <select
                  value={season}
                  onChange={(e) => {
                    setSeason(Number(e.target.value));
                    setEpisode(1);
                  }}
                  className="bg-slate-800 border border-purple-500/30 text-white rounded px-2 py-0.5 font-semibold focus:outline-none focus:border-rose-500 text-xs"
                >
                  {Array.from({ length: Math.max(1, effectiveMeta?.totalSeasons || seriesMeta?.totalSeasons || 1) }, (_, i) => i + 1).map((s) => (
                    <option key={s} value={s}>Season {s}</option>
                  ))}
                </select>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="text-slate-400">Episode:</span>
                <select
                  value={episode}
                  onChange={(e) => setEpisode(Number(e.target.value))}
                  className="bg-slate-800 border border-purple-500/30 text-white rounded px-2 py-0.5 font-semibold focus:outline-none focus:border-rose-500 text-xs"
                >
                  {Array.from({ length: availableEpisodesCount }, (_, i) => i + 1).map((ep) => (
                    <option key={ep} value={ep}>Episode {ep}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex items-center space-x-1.5">
              <button
                type="button"
                disabled={episode <= 1}
                onClick={() => setEpisode((prev) => Math.max(1, prev - 1))}
                className="px-2.5 py-0.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 rounded text-slate-200 font-medium text-xs"
              >
                ◀ Prev
              </button>
              <button
                type="button"
                onClick={() => setEpisode((prev) => prev + 1)}
                className="px-2.5 py-0.5 bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 rounded text-white font-bold text-xs"
              >
                Next ▶
              </button>
            </div>
          </div>
        )}

        {/* Sponsor / Fake Ads Verification Screen (Anti-Bypass Enabled) */}
        {needsPopups && (
          <div 
            className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-950/95 sm:backdrop-blur-md p-4 text-center transition-all select-none"
            onClick={handleFakeClick}
          >
            {/* Play Icon */}
            <div className="w-14 sm:w-20 h-14 sm:h-20 bg-gradient-to-r from-rose-600 to-purple-600 rounded-full flex items-center justify-center shadow-[0_0_35px_rgba(244,63,94,0.5)] transition-transform mb-3 sm:mb-5 cursor-pointer hover:scale-105">
              <Play className="w-6 sm:w-9 h-6 sm:h-9 text-white fill-current ml-0.5 sm:ml-1" />
            </div>
            
            {/* Ad Verification Card */}
            <div className="bg-slate-900/95 border border-purple-500/40 px-5 sm:px-8 py-3.5 sm:py-6 rounded-xl sm:rounded-2xl max-w-xs sm:max-w-md shadow-2xl sm:backdrop-blur-xl">
              <div className="inline-flex items-center space-x-1.5 text-rose-400 text-[10px] sm:text-xs font-semibold uppercase tracking-wider mb-1 sm:mb-2">
                <ShieldCheck className="w-3.5 sm:w-4 h-3.5 sm:h-4" />
                <span>Stream Security Verification</span>
              </div>
              
              <h3 className="text-base sm:text-xl font-bold text-white mb-1">
                Unlock HD Stream
              </h3>

              <p className="text-slate-300 mb-3 sm:mb-4 text-xs sm:text-sm leading-relaxed">
                {`Tap play screen to complete step ${clickCount + 1} of ${targetClicks}.`}
              </p>
              
              {/* Progress Bar */}
              <div className="w-full bg-slate-800 rounded-full h-2 sm:h-2.5 mb-2 overflow-hidden border border-purple-500/20">
                <div 
                  className="bg-gradient-to-r from-rose-500 to-purple-600 h-2 sm:h-2.5 rounded-full transition-all duration-300" 
                  style={{ width: `${(clickCount / targetClicks) * 100}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] sm:text-xs">
                <span className="text-purple-300/70 font-medium">Steps completed</span>
                <span className="text-rose-400 font-bold">{clickCount} / {targetClicks}</span>
              </div>
            </div>
          </div>
        )}

        {/* Floating Server Switch Notification Toast */}
        {serverNotice && (
          <div className="absolute top-12 left-1/2 -translate-x-1/2 z-50 bg-slate-900 border border-purple-500/40 text-white px-4 py-1.5 rounded-full text-xs font-semibold shadow-2xl flex items-center space-x-1.5">
            <Server className="w-3.5 h-3.5 text-rose-400 shrink-0" />
            <span>{serverNotice}</span>
          </div>
        )}

        {/* Floating Hotkey HUD Toast Notification */}
        {hotkeyToast && (
          <div className="absolute top-12 left-1/2 -translate-x-1/2 z-50 bg-slate-950/95 border border-rose-500/60 text-white px-4 py-1.5 rounded-full text-xs font-bold shadow-2xl flex items-center space-x-2 pointer-events-none animate-pulse">
            <span className="text-rose-400">⌨️</span>
            <span>{hotkeyToast}</span>
          </div>
        )}

        {/* Video Player Frame */}
        <div className="w-full h-full relative">
          {/* 🎯 Native ad-free player — shown when a direct stream URL is found */}
          {directStream && !needsPopups ? (
            <NativeArabicPlayer
              key={`native-${directStream.url}`}
              streamUrl={directStream.url}
              streamType={directStream.type}
              subtitleUrl={activeArabicSubUrl}
              poster={thumbnailUrl}
            />
          ) : parsedSources.isDirectVideo ? (
            <video
              ref={videoRef}
              key={`direct-${parsedSources.currentUrl}`}
              controls={!needsPopups}
              className="w-full h-full object-contain"
              poster={thumbnailUrl || undefined}
              src={parsedSources.currentUrl}
              playsInline
            />
          ) : (
            <iframe
              key={`embed-${parsedSources.currentUrl}`}
              src={needsPopups ? undefined : parsedSources.currentUrl}
              className="w-full h-full border-0"
              allowFullScreen
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
              onLoad={() => setIsServerLoaded(true)}
            />
          )}
        </div>

      </div>




      {/* Cinema Theater Lights-Off Fullscreen Mode */}
      {isTheaterMode && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-2 sm:p-4 backdrop-blur-2xl">
          <div className="w-full max-w-6xl flex items-center justify-between pb-2 px-2 text-white">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
              <span className="font-bold text-xs sm:text-sm">Cinema Theater Mode • {title} {isSeries ? `(S${season} : E${episode})` : ""}</span>
            </div>
            <button
              type="button"
              onClick={() => setIsTheaterMode(false)}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-purple-500/20 cursor-pointer shadow"
            >
              <Minimize2 className="w-3.5 h-3.5 text-rose-400" />
              <span>Exit (ESC)</span>
            </button>
          </div>
          <div className="w-full max-w-6xl aspect-video bg-black rounded-2xl overflow-hidden border border-purple-500/30 shadow-2xl relative">
            {parsedSources.isDirectVideo ? (
              <video
                controls
                autoPlay
                className="w-full h-full object-contain"
                src={parsedSources.currentUrl}
                playsInline
              />
            ) : (
              <iframe
                src={parsedSources.currentUrl}
                className="w-full h-full border-0"
                allowFullScreen
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
              />
            )}
          </div>
        </div>
      )}

      {/* Floating Picture-in-Picture Mini-Player */}
      {isFloatingPiP && (
        <div className="fixed bottom-4 right-4 z-50 w-72 sm:w-84 aspect-video bg-black rounded-2xl shadow-2xl border-2 border-purple-500/50 overflow-hidden group">
          <div className="absolute top-2 right-2 z-10 flex items-center space-x-1 opacity-80 group-hover:opacity-100 transition-opacity">
            <button
              type="button"
              onClick={() => {
                setIsFloatingPiP(false);
                const el = document.getElementById("video-player-screen");
                if (el) el.scrollIntoView({ behavior: "smooth" });
              }}
              className="p-1.5 bg-black/80 hover:bg-slate-800 text-white rounded-lg text-xs cursor-pointer shadow"
              title="Expand back to main screen"
            >
              <Maximize2 className="w-3 h-3 text-purple-300" />
            </button>
            <button
              type="button"
              onClick={() => setIsFloatingPiP(false)}
              className="p-1.5 bg-black/80 hover:bg-rose-900 text-white rounded-lg text-xs cursor-pointer shadow"
              title="Close mini player"
            >
              <X className="w-3 h-3 text-rose-300" />
            </button>
          </div>
          {parsedSources.isDirectVideo ? (
            <video
              controls
              autoPlay
              className="w-full h-full object-contain"
              src={parsedSources.currentUrl}
              playsInline
            />
          ) : (
            <iframe
              src={parsedSources.currentUrl}
              className="w-full h-full border-0"
              allowFullScreen
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
            />
          )}
        </div>
      )}

      {/* Cinema Keyboard Shortcuts Cheatsheet Modal */}
      {showHotkeysModal && (
        <div 
          className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-md"
          onClick={() => setShowHotkeysModal(false)}
        >
          <div 
            className="bg-slate-900 border border-purple-500/40 rounded-2xl max-w-sm w-full p-5 shadow-2xl text-white relative animate-fade-in"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setShowHotkeysModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="flex items-center space-x-2.5 mb-4">
              <div className="p-2 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-xl">
                <Keyboard className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Cinema Hotkeys</h3>
                <p className="text-[11px] text-purple-300/60">Quick desktop player shortcuts</p>
              </div>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/60 border border-purple-500/15">
                <span className="text-slate-300">Play / Pause</span>
                <kbd className="px-2 py-0.5 bg-slate-950 border border-purple-500/40 rounded text-[11px] font-mono font-bold text-rose-300">Space / K</kbd>
              </div>
              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/60 border border-purple-500/15">
                <span className="text-slate-300">Cinema Theater Mode</span>
                <kbd className="px-2 py-0.5 bg-slate-950 border border-purple-500/40 rounded text-[11px] font-mono font-bold text-rose-300">T</kbd>
              </div>
              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/60 border border-purple-500/15">
                <span className="text-slate-300">Fullscreen</span>
                <kbd className="px-2 py-0.5 bg-slate-950 border border-purple-500/40 rounded text-[11px] font-mono font-bold text-rose-300">F</kbd>
              </div>
              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/60 border border-purple-500/15">
                <span className="text-slate-300">Mini Floating PiP</span>
                <kbd className="px-2 py-0.5 bg-slate-950 border border-purple-500/40 rounded text-[11px] font-mono font-bold text-rose-300">P</kbd>
              </div>
              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/60 border border-purple-500/15">
                <span className="text-slate-300">Seek 10s Backward / Forward</span>
                <kbd className="px-2 py-0.5 bg-slate-950 border border-purple-500/40 rounded text-[11px] font-mono font-bold text-rose-300">← / →</kbd>
              </div>
              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/60 border border-purple-500/15">
                <span className="text-slate-300">Mute / Unmute</span>
                <kbd className="px-2 py-0.5 bg-slate-950 border border-purple-500/40 rounded text-[11px] font-mono font-bold text-rose-300">M</kbd>
              </div>
              {isSeries && (
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/60 border border-purple-500/15">
                  <span className="text-slate-300">Next Episode</span>
                  <kbd className="px-2 py-0.5 bg-slate-950 border border-purple-500/40 rounded text-[11px] font-mono font-bold text-rose-300">N</kbd>
                </div>
              )}
              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/60 border border-purple-500/15">
                <span className="text-slate-300">Close Modals / Theater</span>
                <kbd className="px-2 py-0.5 bg-slate-950 border border-purple-500/40 rounded text-[11px] font-mono font-bold text-rose-300">ESC</kbd>
              </div>
            </div>

            <p className="text-[10px] text-purple-300/50 mt-3 text-center">
              Press <kbd className="px-1.5 py-0.5 bg-slate-950 rounded border border-slate-700 font-mono text-[10px] text-white">?</kbd> anytime to toggle this modal
            </p>
          </div>
        </div>
      )}

      {/* Dedicated Mobile Controls Bar (Servers + TV Series Episode Switcher) */}
      <div className="flex sm:hidden flex-col gap-2.5 bg-slate-900/95 border border-purple-500/20 p-3 rounded-2xl">
        {/* Mobile Server Selector */}
        {parsedSources.isImdbOrTmdb && (
          <div className="flex flex-col gap-2">
            <span className="text-[11px] text-rose-300 font-bold uppercase tracking-wider flex items-center gap-1 shrink-0">
              <Server className="w-3.5 h-3.5" />
              <span>Server:</span>
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              {serverList.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSelectedServer(s.id)}
                  className={`py-1.5 px-2 rounded-xl text-xs font-bold transition-all text-center min-h-[36px] ${
                    selectedServer === s.id
                      ? "bg-gradient-to-r from-rose-600 to-purple-600 text-white shadow"
                      : "bg-slate-800/80 text-purple-200 border border-purple-500/10"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Mobile TV Series Switcher */}
        {isSeries && (
          <div className="flex flex-col gap-2 pt-2 border-t border-purple-900/30">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 flex-1">
                {/* Season Dropdown */}
                <select
                  value={season}
                  onChange={(e) => {
                    setSeason(Number(e.target.value));
                    setEpisode(1);
                  }}
                  className="bg-slate-800 border border-purple-500/30 text-white rounded-xl px-2.5 py-2 text-xs font-bold flex-1 focus:outline-none focus:border-rose-500 min-h-[40px]"
                >
                  {Array.from({ length: Math.max(1, effectiveMeta?.totalSeasons || seriesMeta?.totalSeasons || 1) }, (_, i) => i + 1).map((s) => (
                    <option key={s} value={s}>Season {s}</option>
                  ))}
                </select>

                {/* Episode Dropdown */}
                <select
                  value={episode}
                  onChange={(e) => setEpisode(Number(e.target.value))}
                  className="bg-slate-800 border border-purple-500/30 text-white rounded-xl px-2.5 py-2 text-xs font-bold flex-1 focus:outline-none focus:border-rose-500 min-h-[40px]"
                >
                  {Array.from({ length: availableEpisodesCount }, (_, i) => i + 1).map((ep) => (
                    <option key={ep} value={ep}>Episode {ep}</option>
                  ))}
                </select>
              </div>

              {/* Prev / Next Episode Buttons */}
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  disabled={episode <= 1}
                  onClick={() => setEpisode((prev) => Math.max(1, prev - 1))}
                  className="p-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 rounded-xl text-slate-200 min-h-[40px] min-w-[40px] flex items-center justify-center border border-purple-500/10"
                  aria-label="Previous episode"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setEpisode((prev) => prev + 1)}
                  className="p-2 bg-gradient-to-r from-rose-600 to-purple-600 rounded-xl text-white min-h-[40px] min-w-[40px] flex items-center justify-center shadow"
                  aria-label="Next episode"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Interactive Full Series Episode Navigator & Grid */}
      {isSeries && (
        <div className="mt-2 sm:mt-4">
          <SeriesEpisodeNavigator
            movieVideoUrl={movieVideoUrl}
            genre={genre}
            currentSeason={season}
            currentEpisode={episode}
            liveMeta={liveMeta}
            onSelectEpisode={(newSeason, newEpisode) => {
              setSeason(newSeason);
              setEpisode(newEpisode);
              const el = document.getElementById("video-player-screen");
              if (el) {
                el.scrollIntoView({ behavior: "smooth", block: "start" });
              }
            }}
          />
        </div>
      )}
    </div>
  );
}
